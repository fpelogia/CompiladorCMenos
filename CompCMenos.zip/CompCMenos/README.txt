[Instruções]

->Executar script run.sh (ou os comandos dentro desse).

->Colocar código a ser compilado em arquivo chamado "sample.c".

->Todas as saídas estão sendo feitas na tela (stdout).
